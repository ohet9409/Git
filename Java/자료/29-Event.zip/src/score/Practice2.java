package score;

public class Practice2 {
	public static void main(String[] args) {
		ScoreForm scoreForm = new ScoreForm();
	}
}





